// =============================================================================
// Data Types
// =============================================================================

export interface LinkedSubscriber {
  id: string
  name: string
  company: string
  mobile: string
  status: 'active' | 'inactive' | 'paused'
  dateSubscribed: string
  incidentCount: number
  submittedCourtChallans?: number
  submittedOnlineChallans?: number
  submittedCourtAmount?: number
  submittedOnlineAmount?: number
}

export interface Payout {
  id: string
  transactionId: string
  amount: number
  date: string
  status: 'completed' | 'pending' | 'failed'
  paymentMethod: string
}

export interface Document {
  id: string
  type: string
  name: string
  uploadedDate: string
}

export interface ActivityLogEntry {
  id: string
  action: string
  timestamp: string
  details: string
}

export interface Vehicle {
  id: string
  registrationNumber: string
  ownerName: string
  vehicleType: 'truck' | 'bus' | 'car' | 'van' | 'auto' | 'two-wheeler'
  make: string
  model: string
  year: number
  status: 'active' | 'inactive' | 'blacklisted'
  incidentCount: number
  lastIncidentDate: string | null
  subscriberId: string
  subscriberName: string
}

export interface RegisteredVisitor {
  id: string
  visitorId: string
  visitorToken: string
  visitDate: string
  visitors: number
}

export interface RegisteredVisitorDetail {
  id: string
  visitorId: string
  visitorName: string
  subscriberId: string
  pendingCourtChallans: number
  pendingOnlineChallans: number
  pendingChallansAmount: number
  pendingCourtChallansAmount: number
  pendingOnlineChallansAmount: number
  contactNumber: string
}

export interface PartnerFollowUp {
  id: string
  activityType: 'onboarding' | 'activation' | 'training' | 'mobilisation'
  subActivityType: 'call' | 'meeting' | 'email' | 'visit' | 'whatsapp'
  notes: string
  createdAt: string
  createdBy: string
}

export interface OutletQR {
  id: string
  qrId: string
  outletId: string
  outletName: string
  totalScans: number
  status: 'active' | 'inactive'
  createdDate: string
}

export interface Outlet {
  id: string
  outletId: string
  name: string
  address: string
  city: string
  state: string
  pinCode: string
  contactPerson: string
  contactPhone: string
  status: 'active' | 'inactive'
  subscriberCount: number
  vehicleCount: number
  openedDate: string
}

export interface Partner {
  id: string
  partnerId: string
  firstName: string
  lastName: string
  email: string
  mobile: string
  companyName: string
  officialEmail: string
  phone: string
  address: string
  country: string
  state: string
  city: string
  pinCode: string
  website?: string
  productsAllowed: string[]
  subscriberTypesAllowed: string[]
  bankAccountNumber: string
  bankName: string
  partnerType: 'challanPay' | 'lots247'
  outlets?: number
  linkedOutlets?: Outlet[]
  registeredVisitorsCount?: number
  registeredVisitors?: RegisteredVisitor[]
  registeredVisitorDetails?: RegisteredVisitorDetail[]
  outletQRs?: OutletQR[]
  followUps?: PartnerFollowUp[]
  vehicles?: number
  linkedVehicles: Vehicle[]
  status: 'active' | 'inactive'
  stage?: 'onboarding' | 'activation' | 'mobilisation'
  onboardingActivity?: 'registration' | 'qrCreation' | 'profileVerification'
  activationActivity?: 'assigned' | 'trained'
  mobilisationActivity?: 'posterCreated' | 'welcomeLetterCreated' | 'keychainCreated' | 'dispatch' | 'delivered'
  assignedTo?: string
  utmSource?: string
  dateOnboarded: string
  linkedSubscribers: LinkedSubscriber[]
  earnings: number
  totalCommission: number
  totalRspBenefit: number
  totalIncidentsSubmitted: number
  totalOnlineChallansSubmitted: number
  totalCourtChallansSubmitted: number
  totalPayouts: number
  payoutHistory: Payout[]
  documents: Document[]
  activityLog: ActivityLogEntry[]
}

// =============================================================================
// Component Props
// =============================================================================

export interface PartnerListProps {
  /** The list of all partners to display */
  partners: Partner[]

  /** Called when user clicks "Add Partner" button */
  onCreate?: () => void

  /** Called when user wants to view partner details */
  onView?: (id: string) => void

  /** Called when user wants to toggle partner status (active/inactive) */
  onToggleStatus?: (id: string, newStatus: 'active' | 'inactive') => void

  /** Called when user searches for a partner by name */
  onSearch?: (query: string) => void

  /** Called when user filters by status */
  onFilterStatus?: (status: 'active' | 'inactive' | 'all') => void

  /** Called when user sorts by a column */
  onSort?: (column: string, direction: 'asc' | 'desc') => void

  /** Called when user clicks "Export" button */
  onExport?: () => void
}

export interface PartnerDetailProps {
  /** The partner to display */
  partner: Partner

  /** Called when user wants to go back to partner list */
  onBack?: () => void

  /** Called when user edits partner information */
  onEditPartner?: (id: string) => void

  /** Called when user wants to view incidents for a linked subscriber */
  onViewIncidents?: (subscriberId: string) => void

  /** Called when user uploads a document */
  onUploadDocument?: (id: string, file: File) => void

  /** Called when user deletes a document */
  onDeleteDocument?: (id: string, documentId: string) => void

  /** Called when user clicks "Add Subscriber" on the subscribers tab (LOTS247 only) */
  onAddSubscriber?: () => void

  /** Called when user clicks "Bulk Import" on the subscribers tab (LOTS247 only) */
  onBulkImportSubscribers?: () => void

  /** Called when user adds a follow-up (ChallanPay only) */
  onAddFollowUp?: (partnerId: string, followUp: { activityType: string; subActivityType: string; notes: string }) => void

  /** Optional list of tabs to show. If not provided, shows all tabs for the partner type. */
  allowedTabs?: ('profile' | 'visitors' | 'registeredVisitors' | 'customers' | 'vehicles' | 'outlets' | 'qrs' | 'followUps' | 'financial' | 'documents' | 'summary' | 'reports')[]
}

export interface AddPartnerProps {
  /** Called when user submits the 4-step onboarding form */
  onSubmit?: (partnerData: Partial<Partner>) => void

  /** Called when user cancels the onboarding flow */
  onCancel?: () => void

  /** Current step in the stepper (1-4) */
  currentStep?: number
}

export interface AddPartnerChallanPayProps {
  /** Called when user submits the 3-step ChallanPay partner form */
  onSubmit?: (data: {
    primaryContact: string
    entityType: 'business' | 'individual' | ''
    businessType: string
    state: string
    pincode: string
    email: string
    permissions: string[]
    dashboardPermissions: string[]
    bankName: string
    bankAccountNumber: string
  }) => void

  /** Called when user cancels the form */
  onCancel?: () => void
}
