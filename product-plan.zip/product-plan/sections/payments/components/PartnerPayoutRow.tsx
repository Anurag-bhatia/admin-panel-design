import { useState } from 'react'
import { MoreHorizontal, CheckCircle } from 'lucide-react'
import type { PartnerPayout } from '../types'

interface PartnerPayoutRowProps {
  payout: PartnerPayout
  isSelected?: boolean
  onSelect?: (selected: boolean) => void
  onViewPartnerProfile?: () => void
  onMarkComplete?: () => void
}

const STATUS_LABELS: Record<string, { label: string; className: string }> = {
  Eligible: {
    label: 'Eligible',
    className: 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400',
  },
  Requested: {
    label: 'Requested',
    className: 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400',
  },
  'Auto-Processed': {
    label: 'Auto-Processed',
    className: 'bg-violet-50 dark:bg-violet-900/20 text-violet-700 dark:text-violet-400',
  },
  Processing: {
    label: 'Processing',
    className: 'bg-cyan-50 dark:bg-cyan-900/20 text-cyan-700 dark:text-cyan-400',
  },
  Processed: {
    label: 'Processed',
    className: 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400',
  },
  Failed: {
    label: 'Failed',
    className: 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400',
  },
}

function formatDate(dateString: string | null): string {
  if (!dateString) return '—'
  const date = new Date(dateString)
  return date.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })
}

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

export function PartnerPayoutRow({
  payout,
  isSelected = false,
  onSelect,
  onViewPartnerProfile,
  onMarkComplete,
}: PartnerPayoutRowProps) {
  const [showMenu, setShowMenu] = useState(false)
  const statusConfig = STATUS_LABELS[payout.status] || {
    label: payout.status,
    className: '',
  }

  return (
    <tr
      className={`border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer ${
        isSelected ? 'bg-cyan-50 dark:bg-cyan-900/10' : ''
      }`}
      onClick={onViewPartnerProfile}
    >
      {/* Checkbox */}
      <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
        <input
          type="checkbox"
          checked={isSelected}
          onChange={(e) => onSelect?.(e.target.checked)}
          className="h-4 w-4 rounded border-slate-300 dark:border-slate-600 text-cyan-600 focus:ring-cyan-500 dark:bg-slate-800"
        />
      </td>

      {/* Partner ID */}
      <td className="px-4 py-3">
        <span className="font-mono text-sm font-medium text-slate-900 dark:text-white">
          {payout.partnerId}
        </span>
      </td>

      {/* Partner Name */}
      <td className="px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="h-7 w-7 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center text-xs font-semibold text-violet-700 dark:text-violet-400">
            {payout.partnerName.charAt(0)}
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-medium text-slate-900 dark:text-white">
              {payout.partnerName}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {payout.companyName}
            </span>
          </div>
        </div>
      </td>

      {/* Total Earnings */}
      <td className="px-4 py-3">
        <span className="text-sm font-semibold text-slate-900 dark:text-white">
          {formatCurrency(payout.totalEarnings)}
        </span>
      </td>

      {/* Payout Amount */}
      <td className="px-4 py-3">
        <span className="text-sm font-medium text-emerald-600 dark:text-emerald-400">
          {formatCurrency(payout.payoutAmount)}
        </span>
      </td>

      {/* Status */}
      <td className="px-4 py-3">
        <span
          className={`inline-flex items-center px-2 py-1 rounded text-xs font-medium ${statusConfig.className}`}
        >
          {statusConfig.label}
        </span>
      </td>

      {/* Due Date */}
      <td className="px-4 py-3">
        <span className="text-sm text-slate-700 dark:text-slate-300">
          {formatDate(payout.dueDate)}
        </span>
      </td>

      {/* Paid Date */}
      <td className="px-4 py-3">
        <span className="text-sm text-slate-700 dark:text-slate-300">
          {formatDate(payout.paidDate)}
        </span>
      </td>

      {/* Actions */}
      <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
          >
            <MoreHorizontal className="h-4 w-4 text-slate-500" />
          </button>

          {showMenu && (
            <>
              <div
                className="fixed inset-0 z-10"
                onClick={() => setShowMenu(false)}
              />
              <div className="absolute right-0 top-full mt-1 w-44 bg-white dark:bg-slate-800 rounded-lg shadow-lg border border-slate-200 dark:border-slate-700 py-1 z-20">
                {['Completed', 'Hold', 'Failed'].map((action) => (
                  <button
                    key={action}
                    onClick={() => {
                      onMarkComplete?.()
                      setShowMenu(false)
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700"
                  >
                    <CheckCircle className="h-4 w-4" />
                    {action}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </td>
    </tr>
  )
}
